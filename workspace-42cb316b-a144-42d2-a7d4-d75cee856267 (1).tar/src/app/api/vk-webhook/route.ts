import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Конфигурация бота (должна быть установлена в переменных окружения)
const VK_ACCESS_TOKEN = process.env.VK_ACCESS_TOKEN || '';
const VK_CONFIRMATION_CODE = process.env.VK_CONFIRMATION_CODE || '';
const VK_GROUP_ID = process.env.VK_GROUP_ID || '';

// Инициализация AI
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZai() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// Функция для отправки сообщения в VK
async function sendVkMessage(userId: number, message: string, keyboard?: object) {
  const url = 'https://api.vk.com/method/messages.send';
  
  const params: Record<string, string | number> = {
    access_token: VK_ACCESS_TOKEN,
    user_id: userId,
    message: message,
    random_id: Math.floor(Math.random() * 1000000000),
    v: '5.199'
  };

  if (keyboard) {
    params.keyboard = JSON.stringify(keyboard);
  }

  const formData = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    formData.append(key, String(value));
  });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString()
    });

    const data = await response.json();
    console.log('VK API response:', data);
    return data;
  } catch (error) {
    console.error('Error sending VK message:', error);
    return null;
  }
}

// Генерация AI ответа
async function generateAIResponse(userMessage: string, userName?: string): Promise<string> {
  try {
    const zai = await getZai();
    
    const systemPrompt = `Ты — дружелюбный и полезный чат-бот для группы ВКонтакте. 
Твоя задача — вести интересную беседу на любые темы, помогать пользователям и отвечать на их вопросы.

Правила поведения:
- Отвечай дружелюбно и с энтузиазмом
- Используй эмодзи для выразительности (но умеренно)
- Если пользователь задаёт вопрос — давай развёрнутый и полезный ответ
- Если пользователь просто здоровается — приветствуй его тепло
- Поддерживай разговор, задавай встречные вопросы когда уместно
- Избегай сухих и коротких ответов
- Пиши на русском языке
- Не используй Markdown форматирование (звёздочки, решётки и т.д.)
${userName ? `- Имя пользователя: ${userName}` : ''}`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      temperature: 0.7,
      max_tokens: 1000
    });

    const response = completion.choices[0]?.message?.content;
    return response || 'Извини, не смог обработать твой запрос. Попробуй ещё раз!';
  } catch (error) {
    console.error('AI generation error:', error);
    return 'Произошла ошибка при обработке сообщения. Попробуй позже!';
  }
}

// Клавиатура с быстрыми командами
function getMainMenuKeyboard() {
  return {
    one_time: false,
    inline: false,
    buttons: [
      [
        {
          action: {
            type: 'text',
            label: '❓ Помощь'
          },
          color: 'primary'
        },
        {
          action: {
            type: 'text',
            label: '📚 О боте'
          },
          color: 'secondary'
        }
      ],
      [
        {
          action: {
            type: 'text',
            label: '💡 Интересный факт'
          },
          color: 'positive'
        },
        {
          action: {
            type: 'text',
            label: '🎮 Анекдот'
          },
          color: 'negative'
        }
      ]
    ]
  };
}

// Обработка специальных команд
async function handleCommand(command: string, userId: number, userName?: string): Promise<string | null> {
  const cmd = command.toLowerCase().trim();
  
  switch (cmd) {
    case 'начать':
    case 'start':
    case '/start':
      return `Привет${userName ? ', ' + userName : ''}! 👋

Я — умный чат-бот для этой группы. Могу:
• Вести беседу на любые темы 💬
• Отвечать на вопросы ❓
• Рассказывать интересные факты 💡
• И просто составить компанию!

Напиши мне что-нибудь, и мы поговорим!`;
    
    case 'помощь':
    case 'help':
    case '/help':
    case '?':
    case '❓ помощь':
      return `📋 Список команд:

• Просто напиши сообщение — и я отвечу!
• "Интересный факт" — расскажу что-то познавательное
• "Анекдот" — пошучу 😄
• "О боте" — информация обо мне

Можешь задать любой вопрос или просто поболтать!`;
    
    case 'о боте':
    case '📚 о боте':
      return `🤖 Обо мне:

Я AI-чат-бот, работающий на базе современных языковых моделей.
Моя задача — быть полезным собеседником!

Технологии:
• Next.js (серверная часть)
• AI для генерации ответов
• VK API для общения с тобой

Создан с любовью к коду 💙`;
    
    case 'интересный факт':
    case '💡 интересный факт':
      return await generateAIResponse('Расскажи один интересный и познавательный факт на тему науки, истории или природы. Ответ должен быть кратким (2-3 предложения) и увлекательным.');
    
    case 'анекдот':
    case '🎮 анекдот':
      return await generateAIResponse('Расскажи короткий и добрый анекдот. Он должен быть смешным, но приличным.');
    
    default:
      return null;
  }
}

// Обработка входящих сообщений
async function handleMessage(userId: number, message: string, userName?: string) {
  console.log(`Message from ${userId}: ${message}`);
  
  // Сначала проверяем, это команда?
  const commandResponse = await handleCommand(message, userId, userName);
  
  if (commandResponse) {
    await sendVkMessage(userId, commandResponse, getMainMenuKeyboard());
    return;
  }
  
  // Если не команда — генерируем AI ответ
  const aiResponse = await generateAIResponse(message, userName);
  await sendVkMessage(userId, aiResponse, getMainMenuKeyboard());
}

// Получение информации о пользователе VK
async function getVkUserInfo(userId: number): Promise<{ first_name: string; last_name: string } | null> {
  try {
    const url = `https://api.vk.com/method/users.get?user_ids=${userId}&access_token=${VK_ACCESS_TOKEN}&v=5.199`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.response && data.response[0]) {
      return {
        first_name: data.response[0].first_name,
        last_name: data.response[0].last_name
      };
    }
    return null;
  } catch (error) {
    console.error('Error getting user info:', error);
    return null;
  }
}

// Main handler
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    console.log('Received webhook:', JSON.stringify(body, null, 2));

    // Подтверждение сервера (при добавлении callback API в настройках группы)
    if (body.type === 'confirmation') {
      console.log('Confirmation request received');
      return new NextResponse(VK_CONFIRMATION_CODE, {
        status: 200,
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    // Обработка новых сообщений
    if (body.type === 'message_new') {
      const message = body.object?.message;
      if (message) {
        const userId = message.from_id;
        const text = message.text || '';
        
        // Получаем имя пользователя
        let userName: string | undefined;
        const userInfo = await getVkUserInfo(userId);
        if (userInfo) {
          userName = userInfo.first_name;
        }
        
        // Обрабатываем сообщение асинхронно (не блокируем ответ VK)
        handleMessage(userId, text, userName).catch(console.error);
      }
      
      // Возвращаем OK сразу, чтобы VK не повторял запрос
      return NextResponse.json({ ok: true });
    }

    // Обработка других событий
    return NextResponse.json({ ok: true });

  } catch (error) {
    console.error('Webhook error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// GET запрос для проверки работы endpoint
export async function GET() {
  return NextResponse.json({
    status: 'VK Bot API is running',
    timestamp: new Date().toISOString(),
    info: 'Configure your VK group callback to POST here'
  });
}
