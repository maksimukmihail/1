'use client'

import { useState } from 'react'

export default function Home() {
  const [copied, setCopied] = useState<string | null>(null)

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const webhookUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/api/vk-webhook`
    : '/api/vk-webhook'

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl shadow-lg mb-4">
            <span className="text-4xl">🤖</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            VK AI Chat Bot
          </h1>
          <p className="text-gray-600 text-lg">
            Умный чат-бот для группы ВКонтакте с AI-ответами
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-4 mb-10">
          <div className="bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-3xl mb-3">💬</div>
            <h3 className="font-semibold text-gray-800 mb-2">Беседы на любые темы</h3>
            <p className="text-gray-600 text-sm">AI генерирует осмысленные ответы на любые сообщения пользователей</p>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-3xl mb-3">⚡</div>
            <h3 className="font-semibold text-gray-800 mb-2">Быстрые команды</h3>
            <p className="text-gray-600 text-sm">Помощь, интересные факты, анекдоты и другое по нажатию кнопки</p>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-3xl mb-3">🎨</div>
            <h3 className="font-semibold text-gray-800 mb-2">Интерактивное меню</h3>
            <p className="text-gray-600 text-sm">Клавиатура с кнопками для быстрого доступа к функциям</p>
          </div>
        </div>

        {/* Setup Instructions */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <span>⚙️</span> Настройка бота
          </h2>

          {/* Step 1 */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">1</span>
              <h3 className="text-lg font-semibold text-gray-800">Создайте токен доступа</h3>
            </div>
            <div className="ml-11 space-y-3">
              <p className="text-gray-600">В настройках группы перейдите в <strong>Управление → Работа с API → Ключи доступа</strong></p>
              <p className="text-gray-600">Создайте новый токен с правами:</p>
              <div className="bg-gray-50 rounded-lg p-4 space-y-1">
                <p className="text-sm text-gray-700">✅ Сообщения сообщества</p>
                <p className="text-sm text-gray-700">✅ Доступ к информации о пользователях</p>
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">2</span>
              <h3 className="text-lg font-semibold text-gray-800">Настройте Callback API</h3>
            </div>
            <div className="ml-11 space-y-3">
              <p className="text-gray-600">В <strong>Управление → Работа с API → Callback API</strong>:</p>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm font-medium text-gray-700 mb-2">URL для webhook:</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-white px-4 py-2 rounded border text-sm overflow-x-auto">
                    {webhookUrl}
                  </code>
                  <button 
                    onClick={() => copyToClipboard(webhookUrl, 'webhook')}
                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors text-sm whitespace-nowrap"
                  >
                    {copied === 'webhook' ? '✓ Скопировано' : 'Копировать'}
                  </button>
                </div>
              </div>

              <p className="text-gray-600">Выберите версию API: <strong>5.199</strong> или выше</p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">3</span>
              <h3 className="text-lg font-semibold text-gray-800">Получите код подтверждения</h3>
            </div>
            <div className="ml-11 space-y-3">
              <p className="text-gray-600">После ввода URL VK покажет строку подтверждения. Скопируйте её.</p>
              <p className="text-gray-600">Также запишите <strong>ID вашей группы</strong> (число в настройках).</p>
            </div>
          </div>

          {/* Step 4 */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">4</span>
              <h3 className="text-lg font-semibold text-gray-800">Настройте переменные окружения</h3>
            </div>
            <div className="ml-11 space-y-3">
              <p className="text-gray-600">Создайте файл <code className="bg-gray-100 px-2 py-1 rounded">.env.local</code> в корне проекта:</p>
              <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
                <pre className="text-green-400 text-sm">
{`VK_ACCESS_TOKEN=ваш_токен_доступа
VK_CONFIRMATION_CODE=код_подтверждения
VK_GROUP_ID=id_вашей_группы`}
                </pre>
              </div>
            </div>
          </div>

          {/* Step 5 */}
          <div className="mb-4">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">5</span>
              <h3 className="text-lg font-semibold text-gray-800">Настройте типы событий</h3>
            </div>
            <div className="ml-11 space-y-3">
              <p className="text-gray-600">В настройках Callback API выберите события:</p>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-700">✅ <strong>message_new</strong> — входящие сообщения</p>
              </div>
            </div>
          </div>
        </div>

        {/* Commands */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <span>🎯</span> Команды бота
          </h2>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="border rounded-xl p-4 hover:border-blue-300 transition-colors">
              <code className="text-blue-600 font-medium">/start</code>
              <p className="text-gray-600 text-sm mt-1">Начать работу с ботом</p>
            </div>
            <div className="border rounded-xl p-4 hover:border-blue-300 transition-colors">
              <code className="text-blue-600 font-medium">Помощь</code>
              <p className="text-gray-600 text-sm mt-1">Список всех команд</p>
            </div>
            <div className="border rounded-xl p-4 hover:border-blue-300 transition-colors">
              <code className="text-blue-600 font-medium">Интересный факт</code>
              <p className="text-gray-600 text-sm mt-1">Познавательная информация</p>
            </div>
            <div className="border rounded-xl p-4 hover:border-blue-300 transition-colors">
              <code className="text-blue-600 font-medium">Анекдот</code>
              <p className="text-gray-600 text-sm mt-1">Поднять настроение</p>
            </div>
            <div className="border rounded-xl p-4 hover:border-blue-300 transition-colors md:col-span-2">
              <code className="text-blue-600 font-medium">Любой текст</code>
              <p className="text-gray-600 text-sm mt-1">AI ответит на любое сообщение осмысленным ответом</p>
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-lg p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">✅</span>
            <h3 className="text-xl font-semibold">Бот готов к работе!</h3>
          </div>
          <p className="opacity-90">
            После настройки переменных окружения бот автоматически начнёт принимать сообщения.
            Напишите в вашу группу ВКонтакте, чтобы проверить!
          </p>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-500 text-sm">
          <p>Powered by Next.js & AI</p>
        </div>
      </div>
    </div>
  )
}
